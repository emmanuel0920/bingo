<?php
	include('../controller/funciones.php');
	user_login();
?>

<link rel="stylesheet" href="assets/css/Estilos_Panteón/panteon.css" />

<div class="breadcrumbs ace-save-state breadcrumbs-fixed" id="breadcrumbs">
    <ul class="breadcrumb">
        <li>
            <i class="ace-icon fa fa-home"></i>
            <a href="#">Inicio</a>
        </li>
        <li class="active">Menú Rápido</li>
    </ul>
</div>

<div class="page-content">
    <div class="page-header">
        
        <h1>COSAS QUE IRÁN EN LA PANTALLA PRINCIPAL
            <small>
                <i class="ace-icon fa fa-angle-double-right">######</i>
            </small>
        </h1>
    </div>  
</div>

<body>
    

</body>

<script> 

    

</script>